

// Start 
This is a react js project with firebase and Mongo db 

npm run dev 



// Programming languages
Typescript and Javascript 



// css animations
animate.css
https://ianlunn.github.io/Hover/
https://animista.net/
https://erictreacy.github.io/mimic.css/
https://nzbin.github.io/three-dots/



// Databases
Mongo db 
Firebase 




// Charts library 
https://echarts.apache.org/examples/en/index.html#chart-type-globe
Chart js 
recharts 
D3js
amcharts
apexcharts 
Flotcharts
Google Charts
react js chart 



// map 
jsvectormap
https://github.com/10bestdesign/jqvmap/
https://jvectormap.com/



// other info
Counter
circlejs
Toggle
dateranger or whatever 
Datepicker




// Styling
Tailwind css
lottie 
Sass
handless ui 
Framer Motion
Flowbite 
Glass UI




// MVC archicture 

Model: The model represents the logic and data of the application. It encapsulates the business rules, data access, and data manipulation logic. In the MVC pattern, the model is independent of both the view and the controller.

Controller: The controller acts as an intermediary between the model and the view. It receives input from the user via the view, processes it, and interacts with the model to perform appropriate actions. The controller updates the model based on user input and also updates the view to reflect changes in the model.

View: The view represents the user interface components of the application. It displays the data from the model to the user and captures user input to pass to the controller. In the MVC pattern, views are responsible for presenting the data in a user-friendly format and handling user interactions.