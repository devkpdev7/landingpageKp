/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/tw-elements-react/dist/js/**/*.js",
  ],
  theme: {
    extend: {
      animation: {
        bounce200: ' bounce 2s ',
      },
      fontFamily: {
        'comodo': ['Comodo', 'sans-serif'],
      },
    },
  },
  plugins: [ ("tw-elements-react/dist/plugin.cjs")
  ],
}

