import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home/Home";
import ScrollToTop from "./assets/windowconfig/ScrollToTop";


import "./index.css";
import PageNotFoundWeb from "./Pages/404/PageNotFound";
import KpForBank from "./Pages/KpForBank/KpForBank";


function App() {
  return (
   <BrowserRouter>
    <ScrollToTop />
    <Routes>
      <Route index  element={<Home />} />
      <Route path="/Bank"  element={<KpForBank />} />
      <Route path="*"  element={<PageNotFoundWeb />} />
      
    </Routes>
   </BrowserRouter>
  );
}

export default App;

