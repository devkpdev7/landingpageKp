import React, { useState, useEffect } from "react";
import Banner from "../../components/Banner/Banner";
import Header from "../../components/Header/Header";
import Hero from "../../components/Hero/Hero";
import Spinner from "../../components/Spinner/Spinner"; // Assuming you have a Spinner component
import BannerTwo from "../../components/BannerTwo/BannerTwo";
import Footer from "../../components/Footer/Footer";
import BannerThree from "../../components/BannerThree/BannerThree";
import BannerFour from "../../components/BannerFour/BannerFour";
import BannerSix from "../../components/BannerSix/BannerSix";
import BannerSeven from "../../components/BannerSeven/BannerSeven";
import "./Home.css";
import CookieModal from "../../components/Cookie/Cookie";
import BannerEight from "../../components/Bannereight/BannerEight";
import BannerNine from "../../components/BannerNine/BannerNine";
import BannerFourCopy from "../../components/BannerFourCopy/BannerFourCopy";
import Faq from "../../components/Faq/Faq";
function Home() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading delay with setTimeout
    const timeout = setTimeout(() => {
      setIsLoading(false);
    }, 2000); // Adjust loading time as needed

    // Cleanup function to clear timeout if component unmounts before loading is finished
    return () => clearTimeout(timeout);
  }, []);

  return (
    <div>
      {isLoading ? (
        <div className="mypage flex justify-center items-center ">
          <Spinner />
        </div>
      ) : (
        <>
          <CookieModal />
          <Header />
          <Hero />
          <Banner />
          <BannerFour />
          <BannerTwo />
          <BannerSeven />
          <BannerEight />
          <BannerNine />
          <BannerThree />
          
          <BannerFourCopy />
          <Faq />
          <BannerSix />

          <Footer />
        </>
      )}
    </div>
  );
}

export default Home;
