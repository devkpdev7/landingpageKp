import React, { useState, useEffect } from "react";
import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import HeroTwo from "../../components/HeroTwo/HeroTwo";
import BannerBank from "../../components/BankBanner/BankBanner";
import BannerTwoBank from "../../components/BannerTwoBank/BannerTwoBank";

function KpForBank() {
  

  return (
    <div>
        <>
         
          <Header />
         
          <BannerTwoBank />
          <Footer />
        </>
    </div>
  );
}

export default KpForBank;
