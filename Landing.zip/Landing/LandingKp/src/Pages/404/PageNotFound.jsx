import { useTranslation } from 'react-i18next';
import PageNotFound from "../../components/Page404/PageNotFound";
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';


export default function PageNotFoundWeb() {
    const { t, i18n } = useTranslation();
    return (
      <>
       <PageNotFound />
       <Footer />
      </>
    )
  }
  

