import React from 'react';
import './Spinner.css'; // Import Spinner styles
import logoWhite from './assets/logo-white.png'; // Import the logo image
import { PuffLoader } from 'react-spinners'; // Import the PuffLoader component
function Spinner() {
  return (
    <div>
      

      <img src={logoWhite} width={90} height={90} alt="Logo" />

      <PuffLoader className='ml-0' size={100} color="#ffffff" />

    </div>
  );
}

export default Spinner;
