import { useTranslation } from 'react-i18next';


export default function BannerFourCopy() {
  const { t, i18n } = useTranslation();
    return (
      <div className=" bg-gradient-to-r from-cyan-500 to-blue-500">
        <div className="px-6 py-24 sm:px-6 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
            {t('Home.resady')}
              <br />
           
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-white">
           {t('Home.partnertwoo')}
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <a
                href="#"
                className=" bg-white px-12 py-2.5 text-sm rounded-full font-semibold text-black  shadow-sm hover:bg-indigo-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
               {t('Home.talkwithus')}
              </a>
             
            </div>
          </div>
        </div>
      </div>
    )
  }
  