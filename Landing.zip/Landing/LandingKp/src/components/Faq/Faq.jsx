import { useTranslation } from "react-i18next";

export default function Faq() {
  const { t } = useTranslation(); // useTranslation hook inside the Faq component

  // Define your FAQs with translated question keys
  const faqs = [
    {
      id: 1,
      questionKey: t("Faq.question1"), // Translate the key here
      answer: t("Faq.answer1"), 
    },
    {
      id: 2,
      questionKey: t("Faq.question2"), // Translate the key here
      answer: t("Faq.answer2"), 
    },
    {
      id: 3,
      questionKey: t("Faq.question3"), // Translate the key here
      answer: t("Faq.answer3"), 
    },
  
    // More questions...
  ];

  return (
    <div className="bg-white dark:bg-gray-900">
      <div className="mx-auto max-w-7xl divide-y divide-gray-900/10 px-6 py-24 sm:py-32 lg:px-8 lg:py-40">
        <h2 className="text-2xl font-bold leading-10 tracking-tight text-gray-900 dark:text-white">
        
          {t('Faq.intro')}

        </h2>
        <dl className="mt-10 space-y-8 divide-y divide-gray-900/10">
          {faqs.map((faq) => (
            <div key={faq.id} className="pt-8 lg:grid lg:grid-cols-12 lg:gap-8">
              <dt className="text-base font-semibold leading-7 text-gray-900 dark:text-white lg:col-span-5">{faq.questionKey}</dt>
              <dd className="mt-4 lg:col-span-7 lg:mt-0">
                <p className="text-base leading-7 text-gray-600 dark:text-white">{faq.answer}</p>
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}
