import React from 'react';
import { motion } from 'framer-motion';
import './BannerBank.css';
import IconPage from '../../assets/icons/security.svg';
import { useTranslation } from 'react-i18next';



function BannerBank() {
 

  const { t, i18n } = useTranslation();
 


  return (
    <section className="bg-white dark:bg-gray-900 md:hidden visible lg:block">
      <div className="grid max-w-screen-xl px-4 py-8 mx-auto gap-8 lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12 md:grid-cols-2">
        <motion.div
          className="mr-auto lg:mx-4  lg:col-span-7 "
        >
          <h1 className="max-w-2xl  mb-4  text-4xl font-extrabold leading-[2.5rem] tracking-tight md:text-5xl xl:text-[45px] dark:text-white">
             <span className='txt-gra'> {t('Bank.kpbank')}<br /> </span> 
          </h1>


          <p className="max-w-xl mb-6 pr-4  rtl:text-right rtl:mr-0 rtl:pr-0  md:pr-32 font-light text-left text-gray-400 lg:mb-8 md:text-lg lg:text-md dark:text-white">
          {t('Bank.kptxtx')}
          </p>
          <a href="#" className="rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 px-3.5 py-3 text-sm font-semibold text-white shadow-sm hover:from-cyan-600 hover:to-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
          {t('Home.openbusiness')}
          </a>
        </motion.div>

        <motion.div
          className="lg:mt-0 lg:col-span-5 lg:flex"
        >
          
         <img src={IconPage} alt='security' className="size-32 md:size" />
          
        </motion.div>
      </div>
    </section>
  );  
}

export default BannerBank;
