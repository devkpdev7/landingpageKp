import React, { useState, useEffect } from 'react';

function CookieModal() {
  const [showModal, setShowModal] = useState(true);

 

  const handleCloseModal = () => {
    setShowModal(false);
    localStorage.setItem('cookiesAccepted', true);
  };

  return (
    <>
      {showModal && (
        <div id="cookies-corner-modal" aria-hidden="false" tabIndex="-1" className="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 w-full md:inset-0 h-modal md:h-full">
          <div className="relative p-4 w-full max-w-xl h-full md:h-auto">
            <div className="relative bg-white rounded-lg shadow dark:bg-gray-800">
              <div className="p-5 text-sm font-light text-gray-500 dark:text-gray-400">
                <p className="mb-2">
                  We use cookies, including third party cookies, for operational purposes, statistical analyses, to personalize your experience, provide you with targeted content tailored to your interests and to analyze the performance of our advertising campaigns.
                </p>
                <p>
                  To find out more about the types of cookies, as well as who sends them on our website, please visit our dedicated guide to <a href="#" className="font-normal text-gray-900 hover:underline dark:text-white">managing cookies</a>.
                </p>
              </div>
              <div className="justify-between items-center p-6 pt-0 space-y-4 sm:flex sm:space-y-0">
                <button onClick={handleCloseModal} type="button" className="py-2 px-4 w-full text-sm font-medium text-center text-white rounded-lg bg-primary-700 sm:w-auto hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Save and close</button>
                <div className="items-center space-y-4 sm:space-x-4 sm:flex sm:space-y-0">
                  <button onClick={handleCloseModal} type="button" className="py-2 px-4 w-full text-sm font-medium text-gray-500 bg-white rounded-lg border border-gray-200 sm:w-auto hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-primary-300 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">Reject all</button>
                  <button onClick={handleCloseModal} type="button" className="py-2 px-4 w-full text-sm font-medium text-center text-white rounded-lg bg-primary-700 sm:w-auto hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Accept all</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default CookieModal;
