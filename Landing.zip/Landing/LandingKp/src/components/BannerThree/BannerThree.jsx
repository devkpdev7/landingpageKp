import { ArrowPathIcon, CloudArrowUpIcon, FingerPrintIcon, LockClosedIcon } from '@heroicons/react/24/outline';
import './BannerThree.css';
import { useTranslation } from 'react-i18next';

export default function BannerThree() {
  const { t } = useTranslation();

  const features = [
    {
      name: t('Home.cookie'),
      description: t('Home.cookiesub'),
      icon: CloudArrowUpIcon,
    },
    {
      name: t('Home.solutions'),
      icon: LockClosedIcon,
    },
    {
      name: t('Home.marketing'),
      icon: ArrowPathIcon,
    },
    {
      name: t('Home.instant'),
      icon: FingerPrintIcon,
    },
  ];

  return (
    <div className="bg-white dark:bg-gray-900 lg:py-24 py-4 sm:py-32 rtl:sm:px-8 hidden">
    <div className="mx-auto max-w-7xl px-6 lg:px-8">
      <div className="mx-auto max-w-2xl lg:text-center">
        <h2 className=" font-semibold leading-7 text-3xl lg:text-2xl txt-gra rtl:text-right">
          {t('Home.forallyourneeds')}
        </h2>
      </div>
      <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
        <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
          {features.map((feature) => (
            <div key={feature.name} className="relative pl-16 rtl:pr-16">
              <dt className="text-base dark:text-white font-semibold leading-7 text-gray-900 rtl:text-right">
                <div className="absolute left-0 top-0 flex h-14 dark:text-white w-14 items-center justify-center rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 ">
                  <feature.icon className="h-6 w-6 text-white dark:text-white" aria-hidden="true" />
                </div>
                {feature.name}
              </dt>
              <dd className="mt-2 text-base leading-7 dark:text-white text-gray-600 rtl:text-right ">{feature.description}</dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  </div>
  
  );
}
