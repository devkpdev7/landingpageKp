import './Hero.css'
import React, {  useEffect } from 'react'
import { motion, useTransform } from 'framer-motion';
import { StarIcon } from '@heroicons/react/20/solid'
import '../../assets/css/hover.css'
import '../../assets/css/wickedcss.min.css'
import '../../assets/css/magic.css'
import imageNow from '../../assets/icons/circle.png'
import { useTranslation } from 'react-i18next'
import  './animate.min.css' 



export default function Hero() {

  const { t, i18n } = useTranslation();








    return (
    
       <motion.div 
       className="relative puffIn   bg-sky-100 dark:bg-gray-900 "> 
        <div className="mx-auto max-w-7xl lg:grid lg:grid-cols-12  lg:gap-x-8 lg:px-8">
          <div className="px-6  pb-24 pt-4 sm:pb-32 lg:col-span-7 lg:px-0 lg:pb-56 lg:pt-24 xl:col-span-6">
            <motion.div
            className="mx-auto max-w-2xl lg:mx-0 example-style lg:mt-36 ">
             
              <div className="hidden sm:mt-32 sm:flex lg:mt-0">
                
              </div>
             
              


              <h1 className="mt-32 lg:mt-0  zoomer text-4xl  font-comodo leading-[3.5rem] md:leading-24 lg:text-[55px] font-bold  tracking-wider txt-gra reverseGradient sm:mt-10 sm:text-6xl leading-extra capitalize">
              {t('Home.your')}
            </h1>

              <p className="mt-6 zoomer rtl:lg:mx-12 rtl:text-right rtl:lg:pr-0 rtl:lg:mr-0  text-l text-left lg:pr-32 leading-8 text-gray-500 dark:text-white ">
              {t('Home.elevate')}
              </p>  



              <div className="mt-10 flex items-center gap-x-6">
              <a href="#" className="rounded-lg zoomer   hvr-sweep-to-right  lg:rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 px-3.5 py-3 text-sm font-semibold text-white shadow-sm hover:from-cyan-600 hover:to-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
               {t('Home.openbusiness')}
              </a>


                <a href="#" className=" invisible  hvr zoomer  lg:visible  rounded-lg bg-gradient-to-r from-white to-white px-3.5 py-3 text-sm font-semibold text-black shadow-sm hover:from-white hover:to-white hover:ring-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
               
                    {t('Home.howitwork')}

                  </a>
              </div>
              <div>
             
              <div className="flex flex-col gap-y-1 text-yellow-500 mt-4">
              <p className='text-[#6473A8] zoomer dark:text-white'>
                📣  {t('Home.We')}
              </p>
              <div className='flex gap-x-1 lg:mt-4'>
                <StarIcon className="h-5 w-5 flex-none" aria-hidden="true" />
                <StarIcon className="h-5 w-5 flex-none" aria-hidden="true" />
                <StarIcon className="h-5 w-5 flex-none" aria-hidden="true" />
                <StarIcon className="h-5 w-5 flex-none" aria-hidden="true" />
                <StarIcon className="h-5 w-5 flex-none" aria-hidden="true" />
              </div>
            </div>


              </div>
            </motion.div>
          </div>


          
          <div  className="relative lg:col-span-5 lg:-mr-8 xl:absolute xl:inset-0 xl:left-1/2 xl:mr-0   rtl:xl:absolute rtl:xl:inset-0 rtl:xl:right-1/2 rtl:xl:mr-0">

         
          <div id='ipad-pro-hidden' className="container zoomer hidden md:hidden lg:block">
            <img src={imageNow} width={300} height={200} alt="hero" className="visible rtl:lg:mr-24 sm:mt-32 sm:flex lg:mt-80 lg:ml-14 absolute -z-5 rotating-image" />
        </div>

           
        <img
        className="zoomer aspect-[3/2] w-full bg-gray-50 object-cover lg:absolute lg:inset-0 lg:aspect-auto lg:h-full"
        src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
        alt=""
      />



          </div>
        </div>
      </motion.div>

        
    )
  }
  