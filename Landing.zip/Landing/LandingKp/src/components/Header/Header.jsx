import { Fragment, useState,useEffect } from "react";
import { Dialog, Disclosure, Popover, Transition } from "@headlessui/react";
import {
  Bars2Icon,
  ChartPieIcon,
  CursorArrowRaysIcon,
  FingerPrintIcon,
  SquaresPlusIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import {
  ChevronDownIcon,
  PhoneIcon,
  PlayCircleIcon,
  RectangleGroupIcon,
} from "@heroicons/react/20/solid";
import "./Header.css";
import logo from "./assets/logo.png"; // Adjust the path as per your project structure
import { useTranslation } from "react-i18next";
import { Link, useLocation } from "react-router-dom";
import logowhite from "./assets/logowhite.png"; // Adjust the path as per your project structure
import menusound from "./assets/menu-selection-102220.mp3";
import '../../assets/css/global.css';

  
import { FiGlobe } from 'react-icons/fi'; // Import globe icon from react-icons library




const callsToAction = [
  { name: "Watch demo", href: "#", icon: PlayCircleIcon },
  { name: "Contact sales", href: "#", icon: PhoneIcon },
  { name: "View all products", href: "#", icon: RectangleGroupIcon },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function Header() {




  const { t, i18n } = useTranslation();
  const location = useLocation();




  const products = [
    {
      name: t('link.increase'),
      description:t('link.reward'),
      href: "#",
      icon: ChartPieIcon,
    },
    {
      name: t('link.attract'),
      description: t('link.attracttxt'),
      href: "#",
      icon: CursorArrowRaysIcon,
    },
    {
      name:t('link.driversales'),
      description: t('link.drivetxt'),
      href: "#",
      icon: FingerPrintIcon,
    },
    {
      name: t('link.customsolutions'),
      description:t('link.giftsd') ,
      href: "#",
      icon: SquaresPlusIcon,
    },
  ];

  const [selectedLanguage, setSelectedLanguage] = useState("en"); // State to manage selected language





  useEffect(() => {
    const savedLanguage = localStorage.getItem("selectedLanguage");
    const lng = savedLanguage || navigator.language;
    i18n.changeLanguage(lng);
    setSelectedLanguage(lng); // Set the selected language in state
  
    // Check if the language is Arabic and set RTL styles if true
    if (lng === "ar") {
      document.body.setAttribute("dir", "rtl"); // Apply RTL direction to the entire body
      // You may need to apply RTL styles to specific elements or classes, depending on your UI structure
    } else {
      document.body.setAttribute("dir", "ltr"); // Set the direction to LTR for other languages
      // Reset any RTL styles that might have been applied previously
    }
  }, [i18n, location.pathname]);
  
  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    setSelectedLanguage(lng); // Set the selected language in state
    localStorage.setItem("selectedLanguage", lng); // Store selected language in local storage
  
    // Check if the language is Arabic and set RTL styles if true
    if (lng === "ar") {
      document.body.setAttribute("dir", "rtl"); // Apply RTL direction to the entire body
      // You may need to apply RTL styles to specific elements or classes, depending on your UI structure
    } else {
      document.body.setAttribute("dir", "ltr"); // Set the direction to LTR for other languages
      // Reset any RTL styles that might have been applied previously
    }
  };
  
  const handleLanguageChange = (event) => {
    const selectedValue = event.target.value;
    changeLanguage(selectedValue);
  };
  

  const audio = new Audio(menusound);
  audio.loop = false;



  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [isIconRotated, setIsIconRotated] = useState(false);

  const handleClick = () => {
    setIsIconRotated(!isIconRotated);
  };

  return (
    <header className="animate-bounce200 delay-50 duration-75 fixed transition-opacity   w-full isolate z-10 bg-white  dark:bg-gray-900 shadow-md">
      <nav
        className="mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8"
        aria-label="Global"
      >
        <div className="flex lg:flex-1">
          <Link to={"/"} href="#" className="-m-1.5 p-1.5">
            
            <span className="sr-only">
              Kp
            </span>
            <img src={logo} className="lg:h-12 dark:hidden lg:w-12 w-8 h-8" alt="Logo" />
<img src={logowhite} className="lg:h-12 hidden dark:block lg:w-12 w-8 h-8" alt="White Logo" />

          </Link>
        </div>
        <div className="flex lg:hidden">
          <button
            type="button"
            className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700 dark:text-white"
            onClick={() => setMobileMenuOpen(true)}
          >
            <span className="sr-only">Open main menu</span>
            <Bars2Icon className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>
        <Popover.Group className="hidden lg:flex lg:gap-x-12">
          <Popover>



            
            <Popover.Button
              className="flex thef hover:border-0 focus:outline-none items-center gap-x-1 text-sm font-semibold leading-6 text-gray-900 dark:text-white"
              onClick={() => {
                handleClick();
                audio.loop = false;
                audio.play();
              }}
            >
              {t('link.linkOne')}
              <ChevronDownIcon
                className={`h-5 w-5 flex-none text-gray-400 ${
                  isIconRotated ? "rotate-180" : ""
                }`}
                aria-hidden="true"
              />
            </Popover.Button>

            <Transition
              as={Fragment}
              enter="transition ease-out duration-200"
              enterFrom="opacity-0 -translate-y-1"
              enterTo="opacity-100 translate-y-0"
              leave="transition ease-in duration-150"
              leaveFrom="opacity-100 translate-y-0"
              leaveTo="opacity-0 -translate-y-1"
            >
              <Popover.Panel className="absolute inset-x-0 top-0 -z-10 bg-white dark:bg-gray-900 dark:ring-gray-900  pt-14 shadow-sm shadow-gray-300 ring-1 ring-white">
                <div className="mx-auto grid max-w-7xl grid-cols-4 gap-x-4 px-6 py-10 lg:px-8 xl:gap-x-8">
                  {products.map((item) => (
                    <div
                      key={item.name}
                      className="group  relative rounded-[17px] p-6 text-sm leading-6 bg-gray-0 dark:hover:bg-gray-800 hover:bg-[#F4F5F7] transition-colors  duration-300 "
                    >
                      <div className="flex h-11 w-11 items-center justify-center rounded-[12px] bg-gray-100 dark:from-cyan-500 dark:to-blue-500 dark:bg-gradient-to-r  group-hover:bg-gray-200 dark:group-hover:bg-gray-900">
                        <item.icon
                          className="h-6 w-6 text-gray-400 dark:text-white group-hover:text-gray-500 dark:group-hover:text-white "
                          aria-hidden="true"
                        />
                      </div>
                      <a
                        href={item.href}
                        className="mt-6 block  hover-element dark:text-white font-semibold text-gray-600 thef"
                      >
                        {item.name}
                        <span className="absolute inset-0" />
                      </a>
                      <p className="mt-1 text-gray-400 dark:text-white fonts">
                        {item.description}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="bg-gray-50">
                  <div className="mx-auto max-w-7xl px-6 lg:px-8"></div>
                </div>
              </Popover.Panel>
            </Transition>
          </Popover>

       

          <Link to={"/bank"} className="text-sm font-semibold leading-6 text-gray-900 thef underline-gradient">
            
            {t('link.linkFour')}
          </Link>

        
        </Popover.Group>
        <div className="hidden lg:flex lg:flex-1 lg:justify-end">
          <div className="group">
            <button className=" rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 px-6 py-4 text-sm font-semibold text-white shadow-sm focus:ring-4 focus:from-ring-cyan-600 focus:to-ring-blue-600  hover:from-cyan-600 hover:to-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-600">
              <a className="text-white  group-hover:outline-none">
              {t('link.linkThree')}
              </a>
            </button>

            <button className="bg-white lg:visible  hover:border-0 border visible md:invisble  hover:border-white border-black hover:text-white hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-500  mx-4   rounded-full px-6 py-3  text-sm font-semibold leading-6 transition-colors duration-0">
             
             {t('link.create')}

            </button>




        
          <select
            className="visible lg:visible max-[1366px]:hidden" 
            value={selectedLanguage}
            onChange={handleLanguageChange}
          >
            <option value="en">
            
              English
              
              </option>
            <option value="ar">Arabic</option>
          </select>



          </div>
        </div>

    










      </nav>
      <Dialog
        as="div"
        className="lg:hidden"
        open={mobileMenuOpen}
        onClose={setMobileMenuOpen}
      >
        <div className="fixed inset-0 z-10" />
        <Dialog.Panel className="fixed inset-y-0 right-0 z-10 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
          <div className="flex items-center justify-between">
            <a href="#" className="-m-1.5 p-1.5">
              <span className="sr-only">Your Company</span>
              <img
                className="h-8 w-auto"
                src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=600"
                alt=""
              />
            </a>
            <button
              type="button"
              className="-m-2.5 rounded-md p-2.5 text-gray-700"
              onClick={() => setMobileMenuOpen(false)}
            >
              <span className="sr-only">Close menu</span>
              <XMarkIcon className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          <div className="mt-6 flow-root">
            <div className="-my-6 divide-y divide-gray-500/10">
              <div className="space-y-2 py-6">
                <Disclosure as="div" className="-mx-3">
                  {({ open }) => (
                    <>
                      <Disclosure.Button className="flex w-full items-center justify-between rounded-lg py-2 pl-3 pr-3.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50">
                        Product
                        <ChevronDownIcon
                          className={classNames(
                            open ? "rotate-180" : "",
                            "h-5 w-5 flex-none"
                          )}
                          aria-hidden="true"
                        />
                      </Disclosure.Button>
                      <Disclosure.Panel className="mt-2 space-y-2">
                        {[...products, ...callsToAction].map((item) => (
                          <Disclosure.Button
                            key={item.name}
                            as="a"
                            href={item.href}
                            className="block rounded-lg py-2 pl-6 pr-3 text-sm font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                          >
                            {item.name}
                          </Disclosure.Button>
                        ))}
                      </Disclosure.Panel>
                    </>
                  )}
                </Disclosure>
                <a
                  href="#"
                  className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                >
                  Payment
                </a>
                <a
                  href="#"
                  className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                >
                  Marketplace
                </a>
                <a
                  href="#"
                  className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                >
                  Company
                </a>
              </div>
              <div className="py-6">
                <a
                  href="#"
                  className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                >
                  Log in
                </a>
              </div>
            </div>
          </div>
        </Dialog.Panel>
      </Dialog>
    </header>
  );
}
