import logo from './assets/logo-white.png'; // Adjust the path as per your project structure
import { useTranslation } from 'react-i18next';

export default function Footer() {
  const { t, i18n } = useTranslation();

  const navigation = {
    solutions: [
      { name: t('Footer.forbusinees'), href: '#' },
    ],
    support: [
      { name: t('Footer.forpartners'), href: '#' },
    ],
    company: [
      { name: t('Footer.aboutus'), href: '#' },
    ],
    legal: [
      { name: t('Footer.terms'), href: '#' },
    ],
    social: [
      {
        name: 'Facebook',
        href: '#',
      },
      {
        name: 'Instagram',
        href: '#',
      },
      // Add other social media items here
    ],
  };

  return (
    <footer className="bg-gradient-to-r from-cyan-500 to-blue-500" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">
        Footer
      </h2>
      <div className="mx-auto max-w-7xl px-6 pb-8 pt-16 sm:pt-24 lg:px-8 lg:pt-32">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8">
            <img src={logo} className="h-16 w-16" alt="Logo" />
            <p className="text-sm leading-6 text-white">
              {t('Footer.text1')}
            </p>
            <div className="flex space-x-6">
              {navigation.social.map((item, index) => (
                <a key={index} href={item.href} className="text-white hover:underline  hover:text-gray-300">
                  <span className="sr-only">{item.name}</span>
                  {/* Your SVG icon component goes here */}
                </a>
              ))}
            </div>
          </div>
          <div className="mt-16 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0">
            <div className="md:grid md:grid-cols-2 md:gap-8">

              <div>
                <h3 className="text-sm font-semibold leading-6 text-white">
                  {t('Footer.header1')}
                </h3>
                <ul role="list" className="mt-6 space-y-4">
                  {navigation.solutions.map((item, index) => (
                    <li key={index}>
                      <a href={item.href} className="text-sm leading-6 hover:underline text-white  hover:text-white">
                        {item.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>


              <div className="mt-10 md:mt-0">
                <h3 className="text-sm font-semibold leading-6  text-white">
                  
                  {t('Footer.header2')}
                </h3>
                <ul role="list" className="mt-6 space-y-4">
                  {navigation.support.map((item) => (
                    <li key={item.name}>
                      <a href={item.href} className="text-sm leading-6 hover:underline text-white  hover:text-white">
                        {item.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>

            </div>





            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold leading-6 text-white">
                  {t('Footer.header3')}
                </h3>
                <ul role="list" className="mt-6 space-y-4">
                  {navigation.company.map((item) => (
                    <li key={item.name}>
                      <a href={item.href} className="text-sm leading-6 hover:underline text-white  hover:text-white">
                        {item.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-10 md:mt-0">
                <h3 className="text-sm font-semibold leading-6 text-white">
                  {t('Footer.header4')}
                </h3>
                <ul role="list" className="mt-6 space-y-4">
                  {navigation.legal.map((item) => (
                    <li key={item.name}>
                      <a href={item.href} className="text-sm leading-6 text-white  hover:underline  hover:text-white">
                        {item.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>





        


              
            
            
          </div>
        </div>
      </div>
    </footer>
  );
}
