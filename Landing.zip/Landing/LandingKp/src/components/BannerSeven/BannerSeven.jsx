import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useTranslation } from 'react-i18next';
import './BannerSeven.css';
import ImgaeDevice from '../../assets/devices/Color=Deep Purple.png'

function BannerSeven() {
  const { t, i18n } = useTranslation();


  return (
    <section className="bg-white dark:bg-gray-900">
      <div className="grid max-w-screen-xl px-4 py-8 mx-auto gap-8 lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12">

      <motion.div
          className="mr-auto place-self-center lg:col-span-7"
        >
          <h1 className="max-w-2xl mb-4   text-2xl lg:text-4xl font-extrabold leading-[2.5rem] tracking-tight md:text-3xl xl:text-[45px] dark:text-white">
           

         
          {t('Home.cookie')}

          </h1>
          <p id='mastertext' className="max-w-xl text-xl mb-6 lg:pr-32 md:pr-32 pr-0  rtl:mr-0 rtl:pr-0 rtl:text-right txt  font-light text-left text-gray-400 lg:mb-8 md:text-lg lg:text-md dark:text-white">
            


          {t('Home.cookiesub')}

          </p>
          <a href="#" id='btn-hidden' className="rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 px-3.5 py-3 text-sm font-semibold text-white shadow-sm hover:from-cyan-600 hover:to-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
            
          {t('Home.openbusiness')}
          </a>
        </motion.div>

        
      <motion.div
          id='divh'
        
          className="lg:mt-0 lg:col-span-5 lg:flex "
        >
         
         <img src={ImgaeDevice} id='device' height={220} width={220} alt="mockup" />
        </motion.div>

        
   

       
      </div>
    </section>
  );
}

export default BannerSeven;
